import React from 'react'

function Participant() {
  return (
    <div>
      
    </div>
  )
}

export default Participant
